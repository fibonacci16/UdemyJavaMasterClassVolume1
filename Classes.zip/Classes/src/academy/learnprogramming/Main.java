package academy.learnprogramming;

public class Main {

    public static void main(String[] args) {

        Car porsche =   new Car();          // make sure this is always executed
        Car holden  =   new Car();

//        System.out.println("Model is " +porsche.getModel());  // not yet intialised

        porsche.setModel("911");
        System.out.println("Model is " +porsche.getModel());


    }
}
