package academy.learnprogramming;
import java.util.Arrays;
import java.util.Scanner;

public class Main {

    // (1) Create a program using arrays that sorts a list of integers in descending order.
    // (2) Descending order is highest value to lowest.
    // (3) In other words, if the array had the values in it:
    //        106, 26, 81, 5, 15 your program should
    //        ultimately have an array with 106, 81, 26, 15, 5 in it.
    // (4) Set up the program so that the numbers to sort are read in from the keyboard.
    // (5) Implement the following methods - getIntegers, printArray, and sortIntegers
    // (6) getIntege rs returns an array of entered integers from keyboard
    // (7) printArray prints out the contents of the array
    // (8) and sortIntegers should sort the array and return a new array containing the sorted numbers
    // (9) you will have to figure out how to copy the array elements from the passed array into a new
    // array and sort them and return the new sorted array.

    // code a line that creates an object accepting an input
    private static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        int[] myIntegers = getIntegers(5);
        int[] sorted = sortIntegers(myIntegers);
        printArray(sorted);
    }

    public static int[] getIntegers(int capacity) {
        int[] array  = new int[capacity];
        System.out.println("Enter " +capacity + " integer values: ");
        for (int i=0; i<array.length; i++) {
            array[i] = scanner.nextInt();
        }
        return array;
    }

    public static void printArray(int[] array) {
        for (int i=0; i<array.length;  i++) {
            System.out.println("Element " +i + " contents " + array[i]);
        }
    }

    public static int[] sortIntegers(int[] array) {
        //create an array that is exactly the same size as the array being sorted
        int[] sortedArray = new int[array.length];
        for (int i=0; i<sortedArray.length;i++) {
            sortedArray[i] = array[i];

        }
        boolean flag = true;
        int temp;
        while (flag) {
            flag = false;
            for(int i =0; i<sortedArray.length-1; i++) {
                if (sortedArray[i] < sortedArray[i+1]) {
                    temp                =   sortedArray[i];
                    sortedArray[i]      =   sortedArray[i+1];
                    sortedArray[i+1]    =   temp;
                    flag                =   true;
                }
            }
        }
        return sortedArray;
    }
}
