// Challenge:
// Create a new class VIP customer
// it should have three fields:  name, credit limit, and email address.
// create three constructors
// 1st constructor:
//      empty should call the constructor with three parameters with default values
// 2nd constructor:
//      should pass on the two values it receives and add a default value for the 3rd
// 3rd constructor
//      should save all fields
// create getters only for this using code generation of IntelliJ as setters won't be needed
//
//  test and confirm if it works

package academy.learnprogramming;

public class VipPerson {
    private String name;
    private double creditLimit;
    private String emailAddress;

    public VipPerson() {
        this("Default name", 50000.00, "default@email.com");
    }

    public VipPerson(String name, double creditLimit) {
        this(name, creditLimit, "unkonwn@email.com");
    }

    public VipPerson(String name, double creditLimit, String emailAddress) {
        this.name = name;
        this.creditLimit = creditLimit;
        this.emailAddress = emailAddress;
    }

    public String getName() {
        return name;
    }

    public double getCreditLimit() {
        return creditLimit;
    }

    public String getEmailAddress() {
        return emailAddress;
    }
}
