package academy.learnprogramming;

public abstract class  ListItem {
    // CREATE THE BASE LISTITEM CLASS
    //create instances of the same class within a class
    protected ListItem rightLink  = null;
    protected ListItem leftLink  = null;

    //lets protect it
    protected Object value;

    //we need a constructor to accept the object parameter

    public ListItem(Object value) {
        this.value = value;
    }


    //code the abstract classes that we need here
    abstract ListItem next();
    abstract ListItem setNext(ListItem item);
    abstract ListItem previous();
    abstract ListItem setPrevious(ListItem item);

    abstract int compareTo(ListItem item);


    public Object getValue() {
        return value;
    }

    public void setValue(Object value) {
        this.value = value;
    }
}
