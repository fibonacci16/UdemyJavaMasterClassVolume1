//Write a method named canPack with three parameters of type int named bigCount, smallCount, and goal.
//
//        The parameter bigCount represents the count of big flour bags (5 kilos each).
//        The parameter smallCount represents the count of small flour bags (1 kilo each).
//        The parameter goal represents the goal amount of kilos of flour needed to assemble a package.
//
//        Therefore, the sum of the kilos of bigCount and smallCount must be at least equal to the value of goal.
//        The method should return true if it is possible to make a package with goal kilos of flour.
//
//        If the sum is greater than goal, ensure that only full bags are used towards the goal amount.
//        For example, if goal = 9, bigCount = 2, and smallCount = 0, the method should return false since
//        each big bag is 5 kilos and cannot be divided. However, if goal = 9, bigCount = 1, and smallCount = 5,
//        the method should return true because of 1 full bigCount bag and 4 full smallCount bags equal goal,
//        and it's okay if there are additional bags left over.
//
//        If any of the parameters are negative, return false.
//
//        EXAMPLE INPUT/OUTPUT:
//        * canPack (1, 0, 4); should return false since bigCount is 1 (big bag of 5 kilos) and goal is 4 kilos.
//        * canPack (1, 0, 5); should return true since bigCount is 1 (big bag of 5 kilos) and goal is 5 kilos.
//        * canPack (0, 5, 4); should return true since smallCount is 5 (small bags of 1 kilo) and goal is 4 kilos,
//                  and we have 1 bag left which is ok as mentioned above.
//        * canPack (2, 2, 11); should return true since bigCount is 2 (big bags 5 kilos each) and smallCount is
//                  2 (small bags of 1 kilo), makes in total 12 kilos and goal is 11 kilos.
//        * canPack (-3, 2, 12); should return false since bigCount is negative.
//
//        NOTE: The method canPack should be defined as public static like we have been doing so far in the course.
//        NOTE: Do not add a main method to the solution code.

package academy.learnprogramming;

public class Main {
    public static void main(String[] args) {


//

        boolean trueCanPack = canPack(2, 1, 5);
        if (trueCanPack) {
            System.out.println("The flour bags provided are packable towards the goal");
        } else {
            System.out.println("The flour bags provided are NOT packable towards the goal");
        }

//        boolean trueCanPack = canPack(1, 0, 4);
//        if (trueCanPack) {
//            System.out.println("The flour bags provided are packable towards the goal");
//        } else {
//            System.out.println("The flour bags provided are NOT packable towards the goal");
//        }
//
//        trueCanPack =  canPack(0, 0, 4);
//        if (trueCanPack) {
//            System.out.println("The flour bags provided are packable towards the goal");
//        } else {
//            System.out.println("The flour bags provided are NOT packable towards the goal");
//        }
//
//
//        trueCanPack =  canPack(0, 5, 4);
//        if (trueCanPack) {
//            System.out.println("The flour bags provided are packable towards the goal");
//        } else {
//            System.out.println("The flour bags provided are NOT packable towards the goal");
//        }
//
//        trueCanPack =  canPack(2, 2, 11);
//        if (trueCanPack) {
//            System.out.println("The flour bags provided are packable towards the goal");
//        } else {
//            System.out.println("The flour bags provided are NOT packable towards the goal");
//        }
//
//        trueCanPack = canPack(-3, 2, 12);
//        if (trueCanPack) {
//            System.out.println("The flour bags provided are packable towards the goal");
//        } else {
//            System.out.println("The flour bags provided are NOT packable towards the goal");
//        }
//
//        trueCanPack = canPack(0, 25, 12);
//        if (trueCanPack) {
//            System.out.println("The flour bags provided are packable towards the goal");
//        } else {
//            System.out.println("The flour bags provided are NOT packable towards the goal");
//        }
//
//        trueCanPack = canPack(1, 2, 6);
//        if (trueCanPack) {
//            System.out.println("The flour bags provided are packable towards the goal");
//        } else {
//            System.out.println("The flour bags provided are NOT packable towards the goal");
//        }
    }

        public static boolean canPack(int bigCount, int smallCount, int goal) {

            //imply negative input values as not accepted
            if ((bigCount < 0) || (smallCount < 0) || (goal < 0)) {
                return false;
            }

            //check how many multiples of 5 kilos there are contained in
            // the goal weight since the intention is to use up big flour bags.

            int goalInMultiple5 = goal/5;

            // If the number of kilos for the big flour go beyond the goal,
            // complement it with the remaining small bags of flour
            // and see if this is sufficient.
            //
            // Otherwise, complement the number of flour bag kilos with
            // remaining weight of small bags of flour.
            //

            if (bigCount > goalInMultiple5) {
                return ((goalInMultiple5 * 5) + smallCount >= goal);
            }
            return ((bigCount*5) +smallCount >= goal);
        }

}
