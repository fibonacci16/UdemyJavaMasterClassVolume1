package academy.learnprogramming;

public class Vehicle {
    public String name;

    public Vehicle (String name) {
        this.name = name;
    }


}
