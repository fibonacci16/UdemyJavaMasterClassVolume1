package academy.learnprogramming;

public class Main {

    public static void main(String[] args) {


        // sample of non-proper encapsulation
//        Player player = new Player();

        //set the value of the fields manually
//        player.name = "Tim";
//        player.health = 20;
//        player.weapon = "Sword";
//
//        int damage = 10;
//        player.loseHealth(damage);
//        System.out.println("Remaining health = " +player.healthRemaining());
//
//        damage = 11;
//        player.health = 200;
//        player.loseHealth(damage);
//        System.out.println("Remaining health = " +player.healthRemaining());

        EnhancedPlayer player = new EnhancedPlayer("Oliver", 200 ,"Sword");
        System.out.println("Initial health is " +player.getHealth());

    }
}

