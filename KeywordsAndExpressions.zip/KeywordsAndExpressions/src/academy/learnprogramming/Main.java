package academy.learnprogramming;

public class Main {

    public static void main(String[] args) {

        // a mile is equal to 1.609344 kilometres
        double kilometres = (100 * 1.609344);
        int highScore = 50;

        if (highScore == 50) {
            System.out.println("This is an expression");
        }
    }
}
