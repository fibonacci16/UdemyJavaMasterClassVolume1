package academy.learnprogramming;

import java.util.Scanner;
public class Main {

    //attribute a data structure which will accept system input
    private static Scanner scanner= new Scanner(System.in);

    //Define an array myIntegers with 5 elements.
    //
    // This array will be equal to the five values returned by the getIntegers method
    //
    // Print out the average

    public static void main(String[] args) {
        int[] myIntegers = getIntegers(5);
        for(int i=0; i<myIntegers.length; i++) {
            System.out.println("Element " +i +", typed value was " +myIntegers[i]);
        }
        System.out.println("The average is "  + getAverage(myIntegers)) ;
    }

    // Define method to return up to 5 integers
    public static int[] getIntegers(int number) {
        System.out.println("Enter " +number +" integer values.\r");
        int[] values = new int[number];

        for (int i=0; i<values.length; i++) {
            values[i] = scanner.nextInt();
        }
        return values;
    }

    //Get the average
    public static double getAverage(int[] array) {
        int sum = 0 ;
        for (int i=0; i <array.length; i++) {
            sum += array[i];
        }
        return (double) sum / (double) array.length;
    }
}
