package academy.learnprogramming;

public class Main {

    public static void main(String[] args) {

        // Using Unicodes
        System.out.println("==============================================");
	    char myChar = 'D';
	    char myUnicodeChar = '\u0044';

        System.out.println(myChar);
        System.out.println(myUnicodeChar);

        char myCopyrightChar = '\u00A9';
        System.out.println(myCopyrightChar);

        // Using Boolean
        System.out.println("==============================================");

        boolean myTrueBooleanValue = true;
        boolean myFalseBooleanValue = false;

        boolean isCustomerOver21 = true;




    }
}
