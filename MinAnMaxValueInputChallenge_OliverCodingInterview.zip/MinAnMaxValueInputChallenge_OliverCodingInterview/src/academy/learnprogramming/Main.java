/* This coding interview challenge will output the minimum and maximul values of
    a set of integers provided by the user input one at a time (prompt);
*/
package academy.learnprogramming;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
	    // 1) We define a Scanner object <scanner> to use to read user input:
        // 2) We define proper parameters to display the min and max integers.

        Scanner scanner = new Scanner(System.in);

        int min = Integer.MAX_VALUE;
        int max = Integer.MIN_VALUE;

        while (true) {
            System.out.println("Enter number:");

            boolean isAnInt = scanner.hasNextInt();

            if (isAnInt) {
                int number = scanner.nextInt();

                if (number > max) {
                    max = number;
                }

                if (number < min) {
                    min = number;
                }

            } else {
                break;
            }
        }

        System.out.println("Max = " +max +", Min = " +min);
        scanner.close();

    }
}
