package academy.learnprogramming;

public class Main {

    public static void main(String[] args) {

        boolean felineIsPlaying = PlayingCat.isCatPlaying(true,10);
        System.out.println("felineIsPlaying = " + felineIsPlaying);
        System.out.println(" ###################### ");
        System.out.println("                         ");


        felineIsPlaying = PlayingCat.isCatPlaying(false,36);
        System.out.println("felineIsPlaying = " + felineIsPlaying);
        System.out.println(" ###################### ");
        System.out.println("                         ");


        felineIsPlaying = PlayingCat.isCatPlaying(false,35);
        System.out.println("felineIsPlaying = " + felineIsPlaying);

    }
}

 class PlayingCat {
    public static boolean isCatPlaying(boolean  summer, int temperature) {

        //this if constrains valid temperature values ranging with (25, 45)

        System.out.println("summer = " + summer);
        System.out.println("temperature = " + temperature);

        if (temperature < 25 || temperature > 45) {
            System.out.println("Invalid Value");
            return false;
        }


        if (temperature <= 35) {
            return true;
        } else if (summer && (temperature > 35)) {
            return true;
        } else {
            return false;
        }
    }
}

