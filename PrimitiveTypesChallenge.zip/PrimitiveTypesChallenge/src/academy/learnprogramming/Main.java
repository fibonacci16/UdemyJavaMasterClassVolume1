package academy.learnprogramming;

public class Main {

    public static void main(String[] args) {
	// 20191027 Exercise with Tim Bulchaka

        byte byteValue      =   100;
        short shortValue    =   20500;
        int intValue        =   -1_111_234_555;

        System.out.println("Byte value is:      " +byteValue);
        System.out.println("Short value is:     " +shortValue);
        System.out.println("Integer value is:   " +intValue);

        //b. No need for casting because number of bit can be contained in a long variable
        long longValue = (5000l + 10l *(byteValue + shortValue+ intValue);
        System.out.println("Resulting Long value is:   " +longValue);

        //c. Needs casting to byte value because default integer is not needed
        long longValue = (5000l + 10l *(byteValue + shortValue+ intValue);
        System.out.println("Resulting Long value is:   " +longValue);

        //d. No need for casting because number of bit can be contained in a long variable
        long longValue = (5000l + 10l *(byteValue + shortValue+ intValue);
        System.out.println("Resulting Long value is:   " +longValue);


    }
}
