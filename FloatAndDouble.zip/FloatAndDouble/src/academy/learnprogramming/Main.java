package academy.learnprogramming;

import jdk.swing.interop.SwingInterOpUtils;

import java.sql.SQLOutput;

public class Main {

    public static void main(String[] args) {

        float myMinFloatValue = Float.MIN_VALUE;
        float myMaxFloatValue = Float.MAX_VALUE;

        System.out.println("Float minimum value = " +myMinFloatValue);
        System.out.println("Float maximum value = " +myMaxFloatValue);

        Double myMinDoubleValue = Double.MIN_VALUE;
        Double myMaxDoubleValue = Double.MAX_VALUE;

        System.out.println("Double minimum value = " +myMinDoubleValue);
        System.out.println("Double maximum value = " +myMaxDoubleValue);

        //value testing

        int myIntValue       =   5 /  3;
        float myFloatValue   =   5f / 3f;
        double myDoubleValue =   5.00 / 3.00;

        System.out.println("MyIntValue = " + myIntValue );
        System.out.println("myFloatValue = " + myFloatValue );
        System.out.println("myDoubleValue = " + myDoubleValue );


        System.out.println("==================================================");
        //Buchalka exercise for weight conversion
        System.out.println("==================================================");

        double poundValue   =   200;
        double poundToKilogramConversionFactor = 0.45359237;

        double convertedKilogramValue =  poundValue * poundToKilogramConversionFactor;


        System.out.println("Pound value to be converted is: " + poundValue +" lb");
        System.out.println("Converted kilogram value is = " +convertedKilogramValue +" kg");

        System.out.println("==================================================");

        double pi =  3.1415927d;
        double anotherNumber =  3_000_000.4_567_890d;


        
    }
}
