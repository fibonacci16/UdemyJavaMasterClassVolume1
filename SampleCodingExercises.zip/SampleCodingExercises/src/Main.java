import java.sql.SQLOutput;

public class Main {
    public static void main(String[] args) {

//**************************************************************
//******* Coding Exercise 1:  for Speed Converter
//**************************************************************
//        long miles = speedConverter.toMilesPerHour(10.5);
//        System.out.println("Miles = " +miles);
//        speedConverter.printConversion(10.5);

//**************************************************************
//******* Coding Exercise 2:  for MegaBytesConverter
//**************************************************************

//        MegaBytesConverter.printMegaBytesAndKiloBytes(2500);
//        MegaBytesConverter.printMegaBytesAndKiloBytes(-1024);
//        MegaBytesConverter.printMegaBytesAndKiloBytes(5000);


//**************************************************************
//******* Coding Exercise 3: for BarkingDog
//**************************************************************


//        boolean wakeUp;
//
//        wakeUp =  BarkingDog.shouldWakeUp(true, 1);
//        if (wakeUp == true) {
//            System.out.println("True! Wake up Oliver!");
//            } else {
//                System.out.println("False! Keep on sleeping Oliver!");
//            }
//
//        wakeUp =  BarkingDog.shouldWakeUp(false, 2);
//        if (wakeUp == true) {
//            System.out.println("True! Wake up Oliver!");
//        } else {
//            System.out.println("False! Keep on sleeping Oliver!");
//        }
//
//        wakeUp =  BarkingDog.shouldWakeUp(true, 8);
//        if (wakeUp == true) {
//            System.out.println("True! Wake up Oliver!");
//        } else {
//            System.out.println("False! Keep on sleeping Oliver!");
//        }
//
//        wakeUp =  BarkingDog.shouldWakeUp(true, -1);
//        if (wakeUp == true) {
//            System.out.println("True! Wake up Oliver!");
//        } else {
//            System.out.println("False! Keep on sleeping Oliver!");
//        }

//**************************************************************
//******* Coding Exercise 4: for Leap Year Calculator
//**************************************************************

//        int inputYear = -1600;
//        boolean isItLeapYear = LeapYear.isLeapYear(inputYear);
//        if (isItLeapYear == true) {
//            System.out.println("True " +inputYear + " is a leap year!");
//        } else {
//            System.out.println("False " +inputYear + " is NOT a leap year!");
//        }
//
//        inputYear = 1600;
//        isItLeapYear = LeapYear.isLeapYear(inputYear);
//        if (isItLeapYear == true) {
//            System.out.println("True " +inputYear + " is a leap year!");
//        } else {
//            System.out.println("False " +inputYear + " is NOT a leap year!");
//        }
//
//        inputYear = 2017;
//        isItLeapYear = LeapYear.isLeapYear(inputYear);
//        if (isItLeapYear == true) {
//            System.out.println("True " +inputYear + " is a leap year!");
//        } else {
//            System.out.println("False " +inputYear + " is NOT a leap year!");
//        }
//
//        inputYear = 2000;
//        isItLeapYear = LeapYear.isLeapYear(inputYear);
//        if (isItLeapYear == true) {
//            System.out.println("True " +inputYear + " is a leap year!");
//        } else {
//            System.out.println("False " +inputYear + " is NOT a leap year!");
//        }

//**************************************************************
//******* Coding Exercise 5: for Decimal Comparator
//**************************************************************

//        boolean itsEqual = DecimalComparator.areEqualByThreeDecimalPlaces(-3.1756, -3.175);
//        if (itsEqual) {
//            System.out.println("The numbers are equal up to three decimal places.");
//        } else {
//            System.out.println("The numbers are NOT equal up to three decimal places.");
//        }
//
//
//        itsEqual = DecimalComparator.areEqualByThreeDecimalPlaces(3.175, 3.176);
//        if (itsEqual) {
//            System.out.println("The numbers are equal up to three decimal places.");
//        } else {
//            System.out.println("The numbers are NOT equal up to three decimal places.");
//        }
//
//        itsEqual = DecimalComparator.areEqualByThreeDecimalPlaces(3.0, 3.0);
//        if (itsEqual) {
//            System.out.println("The numbers are equal up to three decimal places.");
//        } else {
//            System.out.println("The numbers are NOT equal up to three decimal places.");
//        }
//
//
//        itsEqual = DecimalComparator.areEqualByThreeDecimalPlaces(-3.123, 3.123);
//        if (itsEqual) {
//            System.out.println("The numbers are equal up to three decimal places.");
//        } else {
//            System.out.println("The numbers are NOT equal up to three decimal places.");
//        }

//**************************************************************
//******* Coding Exercise 6: for EqualSumChecker
//**************************************************************
//
//        boolean isEqual;
//
//        isEqual = EqualSumChecker.hasEqualSum(1, 1, 1);
//        if (isEqual) {
//            System.out.println("The sum equals the third addend!");
//        } else {
//            System.out.println("The sum does not equal the third addend!");
//        }
//
//        isEqual = EqualSumChecker.hasEqualSum(1, 1, 2);
//        if (isEqual) {
//            System.out.println("The sum equals the third addend!");
//        } else {
//            System.out.println("The sum does not equal the third addend!");
//        }
//
//        isEqual = EqualSumChecker.hasEqualSum(1, -1, 0);
//        if (isEqual) {
//            System.out.println("The sum equals the third addend!");
//        } else {
//            System.out.println("The sum does not equal the third addend!");
//        }
//
//**************************************************************
//******* Coding Exercise 7: for TeenNumberChecker
//**************************************************************

        boolean oneIsATeen = TeenNumberChecker.hasTeen(9, 99, 19);
        if (oneIsATeen) {
            System.out.println("At least one of the ages is a teen.");
            } else {
                 System.out.println("None of the ages is a teen.");
        }

        oneIsATeen = TeenNumberChecker.hasTeen(23, 15, 42);
        if (oneIsATeen) {
            System.out.println("At least one of the ages is a teen.");
        } else {
            System.out.println("None of the ages is a teen.");
        }

        oneIsATeen = TeenNumberChecker.hasTeen(22, 23, 34);
        if (oneIsATeen) {
            System.out.println("At least one of the ages is a teen.");
        } else {
            System.out.println("None of the ages is a teen.");
        }


        boolean thisIsATeenager;

        thisIsATeenager = TeenNumberChecker.isTeen(9);
            if (thisIsATeenager) {
                System.out.println("This is a teenager age.");
            } else {
                System.out.println("This is not a teenager");
            }

        thisIsATeenager = TeenNumberChecker.isTeen(13);
        if (thisIsATeenager) {
            System.out.println("This is a teenager age.");
        } else {
            System.out.println("This is not a teenager.");
        }


    }
}


