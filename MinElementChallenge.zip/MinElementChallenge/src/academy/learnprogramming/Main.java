package academy.learnprogramming;
import java.util.Scanner;

// (1) Write a method called readIntegers() with a parameter called count that represents
//     how many integers the user needs to enter.
// (2) The method needs to read from the console until all the numbers are entered , and
//     then return an array containing the numbers entered.
// (3) Write a method called findMin(0 with the arrays as parameter. The method needs to
//    return the minimum value in the array.
// (4) In the main() method read the count from the console amd call the method
//     readIntegers() with the count parameter.
// (5) Then call the findMin() method passing the array returned from the call
//     to the readIntegers() method.
// (6) Finally, print the minimum  element in the array.
//
// Tips:
//  --> Assume that the user will only enter numbers not letters
//  --> For simplicity, create a Scanner as a static field to help with data input
//  --> Create a new console project with the name 'MinElementsChallenge'

public class Main {
    private static Scanner scanner = new Scanner(System.in);
    public static void main(String[] args) {
        System.out.println("Enter count: "8;
        int count = scanner.nextInt();
        scanner.nextLine();
        int[] returnedArray = readIntegers(count);
        int returnedMin = findMin(returnedArray);

        System.out.println("Returned minimum number = " +returnedMin);

    }

    private static int[] readIntegers(int count) {
        int[] array = new int[count];
        for(int i=0; i<array.length; i++) {
            System.out.println("Enter a number");
            int number = scanner.nextInt();
            scanner.nextLine();
            array[i] = number;

        }
        return array;
    }

    private static int findMin(int[] array) {
        int min = Integer.MAX_VALUE;

        for(int i=0; i<array.length; i++) {
            int value = array[i];

            if (value < min) {
                min = value;
            }
        }

        return min;

    }
}
