package academy.learnprogramming;

public interface CanFly {
    void fly();
}
