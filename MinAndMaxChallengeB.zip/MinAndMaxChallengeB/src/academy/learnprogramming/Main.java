// Read the numbers from the console entered by the user and print the minimum and
// maximum number the user has entered.
//
// Before the user enters the number, print the message "Enter number:"
//
//If the user enters an invalid number, break out of the loop and print
// the minimum and maximum number
// Hint:
// --> Use and endless while
// Bonus
// --> Create a project with the name MinAndMaxInputChallenge
//
// This is an alternate solution without using any boolean flag parameter
// We make use here of the actual minimum and maximum limits of the variable
// min and max which we have defined as initial parameters;

package academy.learnprogramming;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);             //define a Scanner object

        int min = Integer.MAX_VALUE;                         //initialize fields utilising wrapper class Integer
        int max = Integer.MIN_VALUE;

        while (true) {
            System.out.println("Enter number: ");            // prompt for input
            boolean isAnInt = scanner.hasNextInt();         // create boolean to evaluate if the input is valid

            //break out of the loop if the input is not a valid integer

            if (isAnInt) {
                int number = scanner.nextInt();             // assign the input number from the user

                if (number > max) {
                    max = number;
                }

                if (number < min) {
                    min = number;
                }

            } else {
                break;
            }
            scanner.nextLine();
        }

        System.out.println("min = " +min +"," +"max = " +max );
        scanner.close();
    }
}
