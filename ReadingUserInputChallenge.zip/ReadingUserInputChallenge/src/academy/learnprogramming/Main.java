package academy.learnprogramming;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int counter =   0;
        int sum     =   0;

        while (true) {
            int order = counter + 1;
            System.out.println("Enter number #" +order + ":");  // prompt for input

            boolean isAnInt = scanner.hasNextInt();
            if (isAnInt)  {
                int number = scanner.nextInt();            // read the input if valid
                counter++;                                 // increment counter
                sum+=number;                               // accumulate sum
                if (counter == 10) {                       // break out of the loop if the limit 10 has been reached
                    break;
                }
            } else {
                System.out.println("Invalid Number");
            }
            scanner.nextLine();                            // code this for the next prompt
        }

        System.out.println("Sum = " +sum);
        scanner.close();
    }

//
// Alternative solution to the exercise without the use of a break
//
//    public static void main(String[] args) {
//        Scanner scanner = new Scanner(System.in);
//
//        int counter =   0;
//        int sum     =   0;
//
//        while (counter < 1p0) {
//            int order = counter + 1;
//            System.out.println("Enter number #" +order + ":");      // prompt for input
//
//            boolean isAnInt = scanner.hasNextInt();
//            if (isAnInt)  {
//                int number = scanner.nextInt();                     // read the input if valid
//                counter++;                                          // increment counter
//                sum+=number;                                        // accumulate sum
//            } else {
//                System.out.println("Invalid Number");
//            }
//            scanner.nextLine();                                     // code this for the next prompt
//        }
//
//        System.out.println("Sum = " +sum);
//        scanner.close();
//    }

}
