package academy.learnprogramming;

public class Main {

    public static void main(String[] args) {
        double calculatedAreaCircle = AreaCalculator.area(5.0);
        System.out.println(calculatedAreaCircle);

        calculatedAreaCircle = AreaCalculator.area(-1.0);
        System.out.println(calculatedAreaCircle);

        System.out.println("================================================");
        double calculatedAreaRectangle = AreaCalculator.area(5.0, 4.0);
        System.out.println(calculatedAreaRectangle);

        calculatedAreaRectangle = AreaCalculator.area(-1.0, 4.0);
        System.out.println(calculatedAreaRectangle);

    }
}


class AreaCalculator {
    // method to return the area of a circle
    public static double area(double radius) {

        if (radius < 0) {
            return -1;
        }
        return Math.PI * radius * radius;
    }

    // method to return the area of a rectangle
    public static double area(double x, double y) {
        if (x <0 || y <0) {
            return -1;
        }
        return x * y;
    }
}
