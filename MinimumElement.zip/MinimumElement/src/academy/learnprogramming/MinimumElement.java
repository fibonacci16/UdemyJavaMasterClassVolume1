package academy.learnprogramming;

import java.util.Scanner;
public class MinimumElement {




}
