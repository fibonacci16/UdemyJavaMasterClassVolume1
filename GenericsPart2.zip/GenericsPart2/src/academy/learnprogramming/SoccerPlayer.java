package academy.learnprogramming;

public class SoccerPlayer extends Player {

    public SoccerPlayer(String name) {
        super(name);
    }
}
