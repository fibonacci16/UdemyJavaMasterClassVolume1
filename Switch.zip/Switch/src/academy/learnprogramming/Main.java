package academy.learnprogramming;

public class Main {
    public static void main(String[] args) {
//        int value = 2;
//
//        if (value == 1) {
//            System.out.println("Value was 1");
//        } else if (value == 2) {
//            System.out.println("Value was 2");
//        } else {
//            System.out.println("Was not 1 or 2");
//        }

        // Exercise to type a switch statement

        int switchValue = 3;

        switch (switchValue) {
            case 1:
                System.out.println("Value was 1");
                break;
            case 2:
                System.out.println("Value was 2");
                break;
            case 3: case 4: case 5:
                System.out.println("was a 3, or a 4, or a 5");
                System.out.println("Actually it is a " +switchValue);
                break;
            default:
                System.out.println("Was not 1 or 2");
        }

        // Create a new switch statement using char instead of int
        // create a new char variable
        // create switch statement testing for
        // A, B, C, D, and E
        // display a message if any of these are found and then break
        // Add a default which displays a message saying not found

        char charValue = 'B';

        switch (charValue) {
            case 'A':
                System.out.println("Character was 'A'");
                break;
            case 'B':
                System.out.println("Character was 'B'");
                break;
            case 'C':
                System.out.println("Character was 'C'");
                break;
            case 'D':
                System.out.println("Character was 'D");
                break;
            case 'E':
                System.out.println("Character was 'E'");
                break;
            default:
                System.out.println("Character is not found");
        }

        String month = "JANUARy";

        switch (month.toLowerCase()) {
            case "January":
                System.out.println("Jan");
                break;
            case "February":
                System.out.println("Feb");
                break;
            default:
                System.out.println("Not sure");
        }

    }
}
